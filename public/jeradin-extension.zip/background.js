// Session sync, target-tab tracking, and cross-tab Screen Intelligence streaming.
const API_BASE = "https://jeradin.com";
let lastNonJeradinTabId = null;

function isJeradinUrl(url) {
  try {
    const hostname = new URL(url || "").hostname;
    return hostname === "jeradin.com" || hostname === "www.jeradin.com" || hostname.includes("f3f1273c-9023-417a-8f01-2102307dd572");
  } catch { return false; }
}

function isInjectableTab(tab) {
  return Boolean(tab?.id && tab.url && /^(https?|file):/i.test(tab.url));
}

chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab.url && !isJeradinUrl(tab.url) && !tab.url.startsWith("chrome://")) {
      lastNonJeradinTabId = tabId;
      await chrome.storage.local.set({ lastNonJeradinTabId: tabId });
    }
  } catch (_) {}
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete" || !tab.active || !isInjectableTab(tab) || isJeradinUrl(tab.url)) return;
  lastNonJeradinTabId = tabId;
  await chrome.storage.local.set({ lastNonJeradinTabId: tabId });
});

async function sendToTab(tabId, message) {
  try { return await chrome.tabs.sendMessage(tabId, message); }
  catch (_) {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
    await new Promise((resolve) => setTimeout(resolve, 75));
    return chrome.tabs.sendMessage(tabId, message);
  }
}

function normalizedTitle(value) {
  return String(value || "")
    .replace(/\s*[-–—]\s*(Google Chrome|Chromium|Microsoft Edge|Brave|Arc)\s*$/i, "")
    .trim()
    .toLowerCase();
}

async function resolveTargetTab(senderTab, capturedTitle) {
  const senderId = senderTab?.id;
  const wantedTitle = normalizedTitle(capturedTitle);
  const tabs = await chrome.tabs.query({ currentWindow: true });
  const candidates = tabs.filter((tab) => isInjectableTab(tab) && tab.id !== senderId && !isJeradinUrl(tab.url));

  // 1. Match on the captured surface title first — this is the tab the user actually shared.
  if (wantedTitle) {
    const exact = candidates.find((tab) => {
      const title = normalizedTitle(tab.title);
      return title === wantedTitle || title.includes(wantedTitle) || wantedTitle.includes(title);
    });
    if (exact) return exact;
  }

  // 2. Fall back to the last non-Jeradin tab we remembered.
  if (!lastNonJeradinTabId) {
    const stored = await chrome.storage.local.get(["lastNonJeradinTabId"]);
    lastNonJeradinTabId = stored.lastNonJeradinTabId || null;
  }
  if (lastNonJeradinTabId && lastNonJeradinTabId !== senderId) {
    const remembered = candidates.find((tab) => tab.id === lastNonJeradinTabId);
    if (remembered) return remembered;
  }

  // 3. Then the currently-active tab, if it's not Jeradin itself.
  const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (candidates.find((tab) => tab.id === active?.id)) return active;

  // 4. Finally, the most-recently-accessed injectable non-Jeradin tab.
  return candidates.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0))[0] || null;
}

async function streamAnalysis(tabId, payload) {
  const stored = await chrome.storage.local.get(["session"]);
  const token = stored.session?.access_token;
  if (!token) {
    await sendToTab(tabId, { type: "JERADIN_OVERLAY_ERROR", message: "Sign in to Jeradin, then try again." });
    return;
  }
  try {
    const response = await fetch(`${API_BASE}/api/intel/screen/stream`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify(payload),
    });
    if (!response.ok || !response.body) throw new Error((await response.text()).slice(0, 400) || `Analysis failed (${response.status})`);
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let newline = buffer.indexOf("\n");
      while (newline >= 0) {
        const line = buffer.slice(0, newline).trim();
        buffer = buffer.slice(newline + 1);
        if (line) {
          try { await sendToTab(tabId, { type: "JERADIN_OVERLAY_EVENT", event: JSON.parse(line) }); } catch (_) {}
        }
        newline = buffer.indexOf("\n");
      }
    }
    if (buffer.trim()) await sendToTab(tabId, { type: "JERADIN_OVERLAY_EVENT", event: JSON.parse(buffer.trim()) });
  } catch (error) {
    await sendToTab(tabId, { type: "JERADIN_OVERLAY_ERROR", message: error instanceof Error ? error.message : "Analysis failed" }).catch(() => undefined);
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "JERADIN_SESSION" && msg.session?.access_token) {
    chrome.storage.local.set({ session: {
      access_token: msg.session.access_token,
      email: msg.session.email || null,
      expires_at: msg.session.expires_at || null,
      origin: msg.session.origin || API_BASE,
      updated_at: Date.now(),
    } });
    sendResponse({ ok: true });
    return true;
  }
  if (msg?.type === "JERADIN_ANALYZE_ACTIVE_TAB" && msg.payload?.imageBase64) {
    void (async () => {
      const target = await resolveTargetTab(sender.tab, msg.payload.targetTabTitle);
      if (!target?.id || isJeradinUrl(target.url)) throw new Error("No codebase tab was found. Open the tab you want Jeradin to analyze, then stop sharing again.");
      lastNonJeradinTabId = target.id;
      await chrome.storage.local.set({ lastNonJeradinTabId: target.id });
      await sendToTab(target.id, {
        type: "JERADIN_SHOW_OVERLAY",
        title: msg.payload.note || "Screen analysis",
        payload: {
          imageBase64: msg.payload.imageBase64,
          note: msg.payload.note || "",
          sessionId: msg.payload.sessionId,
        },
      });
      void streamAnalysis(target.id, msg.payload);
      sendResponse({ ok: true, tabId: target.id });
    })().catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  // Deep dive re-runs the analysis on the same tab that already has the overlay,
  // so we stream new stage/section events into the existing sheet.
  if (msg?.type === "JERADIN_DEEP_DIVE" && msg.payload?.imageBase64) {
    const tabId = sender.tab?.id;
    if (!tabId) { sendResponse({ ok: false, error: "no-tab" }); return true; }
    void streamAnalysis(tabId, { ...msg.payload, mode: "deep" });
    sendResponse({ ok: true });
    return true;
  }
});
